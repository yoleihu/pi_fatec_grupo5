package graficos;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Spritesheet {
	private BufferedImage spriteSheet;
	
	/* aqui o construtor indica o par�metro onde ser� recebida a imagem a ser processada;
	 * */
	public Spritesheet(String path) {
		// o "getClass" existe em todas as classes, ent�o � um comando que ir� "pegar" esta classe.
		try {
			spriteSheet = ImageIO.read(getClass().getResource(path));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/* indica o par�metro  de localiza��o de quantos pixels a imagem ir� reservar;
	 * @return - Imagem processada;
	 * */
	public BufferedImage getSprite(int x, int y, int width, int height) {
		
		return spriteSheet.getSubimage(x, y, width, height);
	}
}
