package jframes;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import banco.Banco;

public class CadastroJogador extends JFrame{
	//Atributos
	private JButton jbCadastrar;
	private JButton jbVoltar;
	
	private JTextField campoNomeJogador;
	private JTextField campoSenhaJogador;
	
	private JLabel lbNomeJogador;
	private JLabel lbSenhaJogador;
	
	//Construtor
	public CadastroJogador(String titulo) {
		// TODO Auto-generated constructor stub
		inicializarComponentes();
		setTitle(titulo);
	}
	
	/**
	 * Realiza a inicializa��o dos componentes do JFrame
	 * @return - Um tipo void - vazio
	 */
	private void inicializarComponentes() {
		//Dimensionando tela e seu layout
		setBounds(300,100,800,500);
		setLayout(null);
		
		//Criando objeto 
		jbCadastrar = new JButton("CADASTRAR");
		jbVoltar = new JButton("VOLTAR");
		
		campoNomeJogador = new JTextField();
		
		campoSenhaJogador = new JPasswordField();
		
		lbNomeJogador = new JLabel("Insira o seu usu�rio:");
		lbSenhaJogador = new JLabel("Insira uma senha:");
		
		//Adicionando objeto
		add(jbCadastrar);
		add(jbVoltar);
		add(campoNomeJogador);
		add(campoSenhaJogador);
		add(lbSenhaJogador);
		add(lbNomeJogador);
		
		//Dimensionando objeto
		jbCadastrar.setBounds(450,350,200,50);
		jbVoltar.setBounds(150,350,200,50);
		
		campoNomeJogador.setBounds(400,100,200,25);
		campoSenhaJogador.setBounds(400,200,200,25);
		
		lbNomeJogador.setBounds(250,100,200,25);
		lbSenhaJogador.setBounds(250,200,200,25);
		
		//Estilizando elementos
		jbCadastrar.setBackground(Color.black);
		jbCadastrar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		jbCadastrar.setForeground(new Color(208,94,220,255));
				
		jbVoltar.setBackground(Color.black);
		jbVoltar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		jbVoltar.setForeground(new Color(208,94,220,255));
		
		lbNomeJogador.setForeground(new Color(208,94,220,255));
		lbSenhaJogador.setForeground(new Color(208,94,220,255));
		
		campoNomeJogador.setBackground(new Color(208,94,220,255));
		campoNomeJogador.setForeground(Color.black);
		campoNomeJogador.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
				
		campoSenhaJogador.setBackground(new Color(208,94,220,255));
		campoSenhaJogador.setForeground(Color.black);
		campoSenhaJogador.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		
		//Estilizando fundo do JFrame
		getContentPane().setBackground(Color.black);
		
		//Estilizando elementos quando em Mouse Over
		jbCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		    	jbCadastrar.setBackground(new Color(208,94,220,255));
		    	jbCadastrar.setForeground(Color.black);
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		    	jbCadastrar.setBackground(Color.black);
		    	jbCadastrar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		    	jbCadastrar.setForeground(new Color(208,94,220,255));
		    }
		});
		
		jbVoltar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		    	jbVoltar.setBackground(new Color(208,94,220,255));
		    	jbVoltar.setForeground(Color.black);
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		    	jbVoltar.setBackground(Color.black);
		    	jbVoltar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		    	jbVoltar.setForeground( new Color(208,94,220,255));
		    }
		});	
		
		//Acionando o objeto
		jbCadastrar.addActionListener(new ActionListener() {
			
			/* Evento de bot�o que muda tela para "historia"
			 * */
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(campoNomeJogador.getText().equals("") || campoSenhaJogador.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos!");
				}else {
					Banco bd = new Banco();
					bd.abreConexao();
					if(bd.cadastrarJogador(campoNomeJogador.getText(),campoSenhaJogador.getText())) {
						JOptionPane.showMessageDialog(null, "Jogador cadastrado!");
						
						int codRank = bd.encontrarCodRanking(campoNomeJogador.getText());
						bd.fechaConexao();
						Historia historia = new Historia("Hist�ria",codRank);
						historia.setVisible(true);
						historia.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
						dispose();
					}else {
						bd.fechaConexao();
						campoNomeJogador.setText("");
						campoSenhaJogador.setText("");
					}
				}
			}
		});
		/* Bot�o que muda a tela para a primeira tela, "TelaInicial"
		 * */
		jbVoltar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				TelaInicial telaInicial = new TelaInicial("Tela Inicial");
				telaInicial.setVisible(true);
				telaInicial.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
				dispose();
			}
		});
	}
}
