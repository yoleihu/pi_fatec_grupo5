package jframes;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import graficos.Spritesheet;
import mapas.CristalAllMap;

public class Vitoria extends Canvas implements Runnable {
	
	private  boolean isRunning;
	private Thread thread;
	public static JFrame frame;
	private final int WIDTH = 320;
	private final int HEIGHT = 240;
	private final int SCALE = 3;
	private int time = 0;
	
	private BufferedImage image;
	public CristalAllMap cristal;
	public static Spritesheet cristalSheet;
	
	/* O construtor vai indicar a dimens�o da tela e vai iniciar ela,
	 * al�m de iniciar as imagens inseridas;
	 * */
	public Vitoria() {
		setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
		initFrame();	
		//Inicializando os objetos
		
		image = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);
		
		cristalSheet = new Spritesheet("/cristalFinal.png");
		cristal = new CristalAllMap(0,0,32,32,cristalSheet.getSprite(0,0,32,32));
	}
	/* cria a tela
	 * */
	public void initFrame() {
		frame = new JFrame("PARABENS");
		frame.add(this);// para ligar ao "setPreferredSize"
		frame.setResizable(false);// para n�o poderem modificar o tamanho
		frame.pack();
		frame.setLocationRelativeTo(null);// para deixar a janela ao meio da tela
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// op��o de sair
		frame.setVisible(true);
	}
	/* Inicia a atualiza��o e renderiza��o do jogo
	 * */
	public synchronized void start(){
		thread = new Thread(this);
		isRunning = true;
		thread.start();
	}
	
	/* Para a atualiza��o gr�fica e de processo.
	 * */
	public synchronized void stop() {
		isRunning = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/* Contabiliza a atualiza��o para trocar de tela
	 * */
	public void update() {
		if((time/60) >2) {
			Ranking rank = new Ranking("Ranking");
			rank.setVisible(true);
			rank.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
			frame.dispose();
			stop();
			
		}
	}
	/* Utiliza da de um metodo da Runnable para ocorrer o jogo em tempo com atualiza��es
	 * Para a atualiza��o caso usada a fun��o stop.
	 * */
	@Override
	public void run() {
		long lastTime = System.nanoTime();
		double amountOfUpdates = 60.0;
		double ns = 1000000000/ amountOfUpdates;
		// pra explicar o ns, lembre que o computador conta em milisegundos 
		//portanto, se segundo � 1000 milisegundos, em nano, 1 segundo � 1000000000
		double delta = 0;
		int frames= 0;
		double timer = System.currentTimeMillis();
		
		
		while(isRunning) {
			long now = System.nanoTime();
			delta+= (now - lastTime)/ns;
			//quando der 1 no delta, ele fecha um update;
			lastTime = now;
			if(delta >= 1) {
				update();
				render();
				delta --;
				frames ++;
				time++;
				
			}
			if( System.currentTimeMillis()- timer >=1000) {
				System.out.println("FPS: " + frames);
				frames=0;
				timer+=1000;
			}
		}
		stop();
		
		
	}
	/* atualiza graficamente, renderizando imagens na tela.
	 * */
	public void render() {
		BufferStrategy bs = this.getBufferStrategy();// para pegar do Canvas
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = image.getGraphics();
		g.setColor(new Color(0,0,0));
		g.fillRect(0, 0, WIDTH, HEIGHT);
		g.setColor(Color.white);
		g.setFont(new Font("Arial", Font.BOLD, 50));
		g.drawString("VICTORY",50, 120);
		
		cristal.render(g);
		g.dispose();
		g = bs.getDrawGraphics();// peguei o gr�fico principal para 'desenhar' nele.
		
		g.drawImage(image,0,0,WIDTH*SCALE, HEIGHT*SCALE, null);
		bs.show();
		
	}
}
