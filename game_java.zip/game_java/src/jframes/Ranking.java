package jframes;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import banco.Banco;

public class Ranking extends JFrame{
	//Atributos
	private JButton jbFecha, jbVoltar;
	private JTextArea txtRanking;
	private JScrollPane scroll;
	private JLabel jlColocacao, jlUsuario, jlTempo;
	
	//Construtor
	public Ranking(String titulo) {
		// TODO Auto-generated constructor stub
		inicializarComponentes();
		setTitle(titulo);
	}

	/**
	 * Realiza a inicializa��o dos componentes do JFrame
	 * @return - Um tipo void - vazio
	 */
	private void inicializarComponentes() {
	  // TODO Auto-generated method stub
	  //Dimensionando tela e seu layout
	  setLayout(null);//tipo de layout
	  setBounds(300,100,800,500);

      //Criando objeto 
      jbFecha = new JButton("FECHAR JOGO");
      jbVoltar = new JButton("VOLTAR AO IN�CIO");
      jlColocacao = new JLabel("COLOCA��O");
      jlUsuario = new JLabel("JOGADOR");
      jlTempo = new JLabel("TEMPO");
      
      Banco bd = new Banco();
      bd.abreConexao();
      txtRanking = new JTextArea(bd.mostraRanking());
      bd.fechaConexao();
      scroll = new JScrollPane(txtRanking);
      
      //Adicionando objeto
      add(jbFecha);
      add(jbVoltar);
      add(scroll);
      add(jlColocacao);
      add(jlUsuario);
      add(jlTempo);
        
      //Dimensionando objeto
      jbFecha.setBounds(530,375,200,50);
      jbVoltar.setBounds(50,375,200,50);
      scroll.setBounds(50,100,680,250);
      jlColocacao.setBounds(50,30,200,50);
      jlUsuario.setBounds(300,30,200,50);
      jlTempo.setBounds(600,30,200,50);
      
      //Estilizando elementos
      jbFecha.setBackground(Color.black);
      jbFecha.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
      jbFecha.setForeground(new Color(208,94,220,255));
    				
      jbVoltar.setBackground(Color.black);
      jbVoltar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
      jbVoltar.setForeground(new Color(208,94,220,255));
      
      txtRanking.setBackground(Color.black);
      txtRanking.setForeground(new Color(208,94,220,255));
      txtRanking.setEditable(false);
      txtRanking.setFont(new Font("Arial",Font.ITALIC, 20));
      
      jlColocacao.setFont(new Font("Arial",Font.ITALIC, 24));
      jlColocacao.setForeground(new Color(208,94,220,255));
      
      jlUsuario.setFont(new Font("Arial",Font.ITALIC, 24));
      jlUsuario.setForeground(new Color(208,94,220,255));
      
      jlTempo.setFont(new Font("Arial",Font.ITALIC, 24));
      jlTempo.setForeground(new Color(208,94,220,255));
      
      scroll.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
      
      //Estilizando elementos quando em Mouse Over
      jbFecha.addMouseListener(new java.awt.event.MouseAdapter() {
 	    public void mouseEntered(java.awt.event.MouseEvent evt) {
 	    	jbFecha.setBackground(new Color(208,94,220,255));
 	    	jbFecha.setForeground(Color.black);
 	    }
        public void mouseExited(java.awt.event.MouseEvent evt) {
        	jbFecha.setBackground(Color.black);
        	jbFecha.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
        	jbFecha.setForeground(new Color(208,94,220,255));
        }
    });
    		
    jbVoltar.addMouseListener(new java.awt.event.MouseAdapter() {
   		    public void mouseEntered(java.awt.event.MouseEvent evt) {
   		    	jbVoltar.setBackground(new Color(208,94,220,255));
   		    	jbVoltar.setForeground(Color.black);
   		    }
   		    public void mouseExited(java.awt.event.MouseEvent evt) {
   		    	jbVoltar.setBackground(Color.black);
   		    	jbVoltar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
   		    	jbVoltar.setForeground( new Color(208,94,220,255));
   		    }
    		});	

    
	//Acionando o objeto
    jbFecha.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.exit(0);
		}
	});
	
	jbVoltar.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			TelaInicial telaInicial = new TelaInicial("Tela Inicial");
			telaInicial.setVisible(true);
			telaInicial.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
			dispose();
		}
	});
	
	//Estilizando fundo do JFrame
	getContentPane().setBackground(Color.black);
	
	}
}
