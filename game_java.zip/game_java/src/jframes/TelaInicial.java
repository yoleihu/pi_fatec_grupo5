package jframes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;

public class TelaInicial extends JFrame{
private BufferedImage image;
	
	//Atributos
	private JButton jbNovo;
	private JButton jbJaPossui;
	
	//Construtor
	public TelaInicial(String titulo) {
		// TODO Auto-generated constructor stub
		inicializarComponentes();
		setTitle(titulo);

		/*image = new BufferedImage(800,500,BufferedImage.TYPE_INT_RGB);*/
	}
		
	/**
	 * Realiza a inicializa��o dos componentes do JFrame
	 * @return - Um tipo void - vazio
	 */
	private void inicializarComponentes() {
		//Dimensionando tela e seu layout
		setBounds(300,100,800,500);
		setLayout(null);
		
		//Criando objeto 
		jbNovo = new JButton("NOVO JOGADOR");
		jbJaPossui = new JButton("J� TENHO CADASTRO");
		
		
		//Adicionando objeto
		add(jbNovo);
		add(jbJaPossui);
		
		//Acionando o objeto
		jbNovo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CadastroJogador cadastro = new CadastroJogador("Cadastro");
				cadastro.setVisible(true);
				cadastro.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
				dispose();
			}
		});
		
		jbJaPossui.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				LoginJogador login = new LoginJogador("Login");
				login.setVisible(true);
				login.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
				dispose();
			}
		});

		
		
		//Dimensionando objeto
		jbNovo.setBounds(300,150,200,50);
		jbJaPossui.setBounds(300,250,200,50);
		
		
		
		
		//Estilizando elementos
		jbNovo.setBackground(Color.black);
		jbNovo.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		jbNovo.setForeground(new Color(208,94,220,255));
		
		jbJaPossui.setBackground(Color.black);
		jbJaPossui.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		jbJaPossui.setForeground(new Color(208,94,220,255));
		
		//Estilizando fundo do JFrame
		getContentPane().setBackground(Color.black);
		
		//Estilizando elementos quando em Mouse Over
		jbNovo.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		    	jbNovo.setBackground(new Color(208,94,220,255));
		    	jbNovo.setForeground(Color.black);
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		    	jbNovo.setBackground(Color.black);
				jbNovo.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
				jbNovo.setForeground(new Color(208,94,220,255));
		    }
		});
		
		jbJaPossui.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		    	jbJaPossui.setBackground(new Color(208,94,220,255));
		    	jbJaPossui.setForeground(Color.black);
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		    	jbJaPossui.setBackground(Color.black);
				jbJaPossui.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
				jbJaPossui.setForeground( new Color(208,94,220,255));
		    }
		});
		
	}
}
