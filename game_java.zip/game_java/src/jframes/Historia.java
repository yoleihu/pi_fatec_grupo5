package jframes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import banco.Banco;
import game_java.Jogo;

public class Historia extends JFrame{
	//Atributos
	private JTextArea txtHistoria;
	private JButton jbAvancar;
	private JScrollPane scroll;
	private int codRanking = 0;
	
	//Construtor
	public Historia(String titulo, int codRank) {
		// TODO Auto-generated constructor stub
		inicializarComponentes();
		setTitle(titulo);
		this.codRanking=codRank;
	}

	/**
	 * Realiza a inicializa��o dos componentes do JFrame
	 * @return - Um tipo void - vazio
	 */
	private void inicializarComponentes() {
	// TODO Auto-generated method stub
		//Dimensionando tela e seu layout
		setBounds(300,100,800,500);
		setLayout(null);
		
		//Criando objeto 
		jbAvancar = new JButton("AVAN�AR");
		txtHistoria = new JTextArea("\n\n           O reino m�gico precisa de voc�!"
                + "\n\n           A poderosa feiticeira Morgana acaba de roubar as preciosas"
                + "\n        SEASON GEMS, as j�ias que controlam as diferentes esta��es."
                + "\n        Sem elas o reino corre perigo, precisamos de voc�!"
                + "\n\n           Ajude a bruxinha Luna a recuperar as j�ias e restaurar o"
                + "\n        equil�brio da natureza! "
                + "\n\n           Recupere a cada fase um fragmento da poderosa j�ia, e fuja"
                + "\n        de Morgana, porque caso ela te pegue, toda a sua jornada ser�"
                + "\n        em v�o!\n\n");
		scroll = new JScrollPane(txtHistoria);
		
		//Adicionando objeto
		add(scroll);
		add(jbAvancar);
		
		//Dimensionando objeto
		scroll.setBounds(50,50,680,300);
		jbAvancar.setBounds(530,375,200,50);
		
		//Acionando o objeto
		jbAvancar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Jogo jogo = new Jogo();
				jogo.start(codRanking);
				jogo.frame.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
				dispose();
				
			}
		});
		
		//Estilizando elementos
		txtHistoria.setBackground(Color.black);
		txtHistoria.setForeground(new Color(208,94,220,255));
		txtHistoria.setEditable(false);
		txtHistoria.setFont(new Font("Arial",Font.ITALIC, 20));
		
		jbAvancar.setBackground(Color.black);
		jbAvancar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		jbAvancar.setForeground(new Color(208,94,220,255));
		
		scroll.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		
		//Estilizando elementos quando em Mouse Over
		jbAvancar.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseEntered(java.awt.event.MouseEvent evt) {
		    	jbAvancar.setBackground(new Color(208,94,220,255));
		    	jbAvancar.setForeground(Color.black);
		    }

		    public void mouseExited(java.awt.event.MouseEvent evt) {
		    	jbAvancar.setBackground(Color.black);
		    	jbAvancar.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, new Color(208,94,220,255)));
		    	jbAvancar.setForeground(new Color(208,94,220,255));
		    }
		});		
		
		//Estilizando fundo do JFrame
		getContentPane().setBackground(Color.black);
	}
}
