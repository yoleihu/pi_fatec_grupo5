package mapas;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import entities.Entity;
import jframes.Vitoria;

public class CristalAllMap extends Entity {
	
	private BufferedImage[] cristal;

	public CristalAllMap(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
		cristal = new BufferedImage[1];
		
		cristal[0] = Vitoria.cristalSheet.getSprite(0,0,32,32);
	
	}
	
	public void render(Graphics g) {
		
		g.drawImage(cristal[0],150,150,null);
	}
	
	
}
