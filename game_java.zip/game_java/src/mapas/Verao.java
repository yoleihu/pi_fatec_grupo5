package mapas;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import entities.Entity;
import game_java.Jogo;

public class Verao extends Entity {
	
	private BufferedImage[] floor;
	

	public Verao(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
		floor = new BufferedImage[3];
		
		floor[0] = Jogo.spriteTileV.getSprite(0, 0, 32, 32);
		floor[1] = Jogo.spriteTileV.getSprite(32, 0, 32, 32);
		floor[2] = Jogo.spriteTileV.getSprite(64, 0, 32, 32);
				
	}

	public void render(Graphics g) {
	
		
		for(int i=0;i<10;i++) {
			for(int j=0; j<8;j++) {
				g.drawImage(floor[0], 32*i, 32*j, null);
				
				
				if( i==9 && j ==0) {
					g.drawImage(floor[1], 32*i, 32*j, null);
				}
			}
			
		}
		
		g.drawImage(floor[2],200, 100, null);
		
	}
}
