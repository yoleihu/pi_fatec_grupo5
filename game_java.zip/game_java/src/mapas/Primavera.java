package mapas;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import entities.Entity;
import game_java.Jogo;

public class Primavera extends Entity{
	
	private BufferedImage[] floor;
	
	public Primavera(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
		floor = new BufferedImage[2];
		
		floor[0] = Jogo.spriteTileP.getSprite(0, 0, 32, 32);
		floor[1] = Jogo.spriteTileP.getSprite(32, 0, 32, 32);
				
	
	}
	
	public void render(Graphics g) {
	
		for(int i=0;i<10;i++) {
			for(int j=0; j<8;j++) {
				g.drawImage(floor[0], 32*i, 32*j, null);
			}
			
		}
		
		g.drawImage(floor[1], 200, 100, null);
	}

}
