package mapas;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import entities.Entity;
import game_java.Jogo;

public class Inverno extends Entity {
	
	private BufferedImage[] floor;
		
	public Inverno(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
		floor = new BufferedImage[4];
		
		floor[0] = Jogo.spriteTileI.getSprite(0, 0, 32, 32);
		floor[1] = Jogo.spriteTileI.getSprite(32, 0, 32, 32);
		floor[2] = Jogo.spriteTileI.getSprite(64, 0, 32, 32);
		floor[3] = Jogo.spriteTileI.getSprite(96, 0, 32, 32);
				
	}

	public void render(Graphics g) {
		
		for(int i=0;i<11;i++) {
			for(int j=0; j<8;j++) {
				g.drawImage(floor[1], 32*i, 32*j, null);
				
				
				if(i>=6 && j<=4) {
					g.drawImage(floor[0], 32*i, 32*j, null);
				}
				else if(i>=7 && j>=5) {
					g.drawImage(floor[0], 32*i, 32*j, null);
				}
				if(j == 0 && i % 3 ==0) {
					g.drawImage(floor[2], 32*i, 32*j, null);
				}
			}
			
		}
		g.drawImage(floor[3],200,100, null);
		
	}
}