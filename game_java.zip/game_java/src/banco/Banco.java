package banco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.Dictionary;
import java.util.Hashtable;

import javax.swing.JOptionPane;
import javax.swing.text.TabableView;

public class Banco {
	
	public static Connection con = null; //Objeto de conex�o
	public static PreparedStatement st = null; //Executa instru��es em SQL
	public static ResultSet rs = null; //Recebe o resultado de uma query

	private final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String BANCO = "projeto_pi"; 
	private final String URL = "jdbc:sqlserver://localhost:1433;databasename="+BANCO;
	private final String LOGIN = "sa";
	private final String SENHA = "12345";
	
	/**
	 * Realiza a conex�o ao banco de dados
	 * @return - Um tipo booleano que indica o sucesso ou n�o da conex�o
	 */
	public boolean abreConexao() {
		try {
			Class.forName(DRIVER); 
			con = DriverManager.getConnection(URL,LOGIN,SENHA);
			System.out.println("Conectou!");
			return true;
		}
		catch(ClassNotFoundException erro) {
			System.out.println("Falha no carregamento do driver!");
		} 
		catch (SQLException erro) {
			System.out.println(erro.toString());
		}
		return false;
	}

	/**
	 * Encerra a conex�o com o banco de dados
	 * @return - Um tipo booleano que indica o sucesso ou n�o da conex�o
	 */
	public void fechaConexao() {		
		try { if(rs!=null) rs.close(); }
		catch(SQLException erro) {}

		try { if(st!=null) st.close();	}
		catch(SQLException erro) {}

		try {
			if(con!=null) {
				con.close();
				System.out.println("Desconectou!");
			}
		}
		catch(SQLException erro) {}
	}
	
	/**
	 * Encontra o c�digo do Ranking a partir do nome e fase do jogador
	 * @return - Um tipo int com o c�digo do ranking
	 */
	public int encontrarCodRanking(String nome) {
		int codRanking=0;
		try {
			
			st = con.prepareStatement("select * from ranking, jogador where cod_jogador=fk_cod_jogador AND nome_jogador=? AND fk_cod_fase<>5");
			st.setString(1, nome);
			st.executeQuery();
			
			rs = st.getResultSet();
			
			while(rs.next()) {
				codRanking=rs.getInt("cod_ranking");
			}
			return codRanking;
		}catch(SQLException erro){
			System.out.println(erro);
			return 0;
		}
	}
	
	/**
     * Realiza a busca do ranking correspondente ao jogador e o cadastra no ranking - Banco de dados
     * @return - Um tipo boolean que indica o sucesso ou n�o da inser��o
     */
    public boolean cadastrarRanking(String nome, String senha) {
    // TODO Auto-generated method stub
        boolean sitInsercao=false;
        int codJogador=0;
        try {   
            st = con.prepareStatement("select cod_jogador from jogador where nome_jogador=? AND senha_jogador=? AND num_vidas=3");
            st.setString(1, nome);
            st.setString(2, senha);
            st.executeQuery();

            rs = st.getResultSet();

            while(rs.next()) {
                if(rs.getInt("cod_jogador")!=0) {
                    try {
                        st = con.prepareStatement("insert into ranking values(?,?,?)");
                        st.setString(1, "00:00:00");
                        st.setInt(2, rs.getInt("cod_jogador"));
                        st.setInt(3, 1);
                        st.executeUpdate();
                        System.out.println("Cadastrado na fase 1");
                        encontrarCodRanking(nome);
                        sitInsercao=true;
                    }catch(SQLException erro) {
                        System.out.println(erro);
                        return sitInsercao;
                    }
                }
                return sitInsercao;
            }
        }catch(SQLException erro) {
            System.out.println(erro);
            return sitInsercao;
        }
        return sitInsercao;
    }
    
	/**
	 * Realiza o cadastro do jogador no banco de dados
	 * @return - Um tipo boolean que indica o sucesso ou n�o da inser��o
	 */
	public boolean cadastrarJogador(String nome, String senha) {
	// TODO Auto-generated method stub
		try {
			boolean existencia=false;
			
			st = con.prepareStatement("select * from jogador");
			st.executeQuery();
			
			rs = st.getResultSet();
				
			while(rs.next()) {
				if(rs.getString("nome_jogador").equals(nome)) {
					existencia=true;
				}
			}
			
			if(existencia) {
				JOptionPane.showMessageDialog(null, "Este usu�rio j� existe!");
				return false;
			}else {
				try {
					st = con.prepareStatement("insert into jogador values(?,?,?)");
					st.setString(1, nome);
					st.setInt(2, 3);
					st.setString(3, senha);
					st.executeUpdate();
					cadastrarRanking(nome, senha);
					System.out.println("Cadastrado!");
					return true;
				}catch(SQLException erro) {
					System.out.println(erro);
					return false;
				}
			}
		}catch(SQLException erro) {
			System.out.println(erro);
			return false;
		}
	}
	
	/**
	 * Realiza a verifica��o dos dados do jogador
	 * @return - Um tipo boolean que indica o sucesso ou n�o da verifica��o
	 */
	public boolean loginJogador(String nome, String senha) {
	// TODO Auto-generated method stub
		
		try {
			boolean sitLogin=false;
			st = con.prepareStatement("select * from jogador");
			st.executeQuery();
			rs = st.getResultSet();
				
			while(rs.next()) {
				if(rs.getString("nome_jogador").equals(nome) && rs.getString("senha_jogador").equals(senha)) {
					sitLogin=true;
				}
			}
			
			encontrarCodRanking(nome);
			return sitLogin;
		}catch(SQLException erro) {
			System.out.println(erro);
			return false;
		}
	}
	
	/**
	 * Realiza a pesquisa dos dados do ranking na ordem do mais r�pido ao mais lento jogador
	 * @return - Um tipo String com os dados encontrados
	 */
	public String mostraRanking() {
	// TODO Auto-generated method stub
		String ranking="";
		try {
			int colocacao=1;
			st = con.prepareStatement("select nome_jogador, tempo from jogador, ranking WHERE cod_jogador=fk_cod_jogador AND fk_cod_fase=5 order by tempo");
			st.executeQuery();
			rs = st.getResultSet();
				
			while(rs.next()) {
				ranking+="\n            "
						+colocacao+"�                                "
						+rs.getString("nome_jogador")+"                     "
						+rs.getString("tempo");
				colocacao++;
			}
			
			return ranking;
		}catch(SQLException erro) {
			System.out.println(erro);
			return ranking;
		}
	}
	
	/**
	 * Realiza o update da fase do jogador guardado na tabela de ranking
	 * @return - Um tipo boolean que indica o sucesso ou n�o do update
	 */
	public boolean trocaFase(int codRanking, int codFase, int timeJogo){
		try {
			st = con.prepareStatement("update ranking set fk_cod_fase=?, tempo=DATEADD(second,?,tempo)  WHERE cod_ranking=?");
			st.setInt(1, codFase);
			st.setInt(2,timeJogo);
			st.setInt(3, codRanking);
			st.executeUpdate();
			return true;
		}catch(SQLException erro) {
			System.out.println(erro);
			return false;
		}
	}
	
	/**
	 * Realiza o update do n�mero de vidas do jogador
	 * @return - Um tipo boolean que indica o sucesso ou n�o do update
	 */
	public boolean perdeVida(int codRanking) {
		int codJogador=0;
		
		try {
			
			st = con.prepareStatement("select fk_cod_jogador from ranking where cod_ranking=?");
			st.setInt(1, codRanking);
			st.executeQuery();
			rs = st.getResultSet();
				
			while(rs.next()) {
				codJogador=rs.getInt("fk_cod_jogador");
			}

			st = con.prepareStatement("update jogador set num_vidas=num_vidas-1 WHERE cod_jogador=?");
			st.setInt(1, codJogador);
			st.executeUpdate();
		
			return true;
		}catch(SQLException erro) {
			System.out.println(erro);
			return false;
		}
	}

}
