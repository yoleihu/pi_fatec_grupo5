package entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import game_java.Jogo;

public class Enemy extends Entity {
	
	private BufferedImage[] enemyWalk;
	private double speed = 1.4;
	public static int x=180;
	public static int y=90;

	/* O construtor recebe mesmos par�metros que a Entity, para que seja localizada e preenchida a imagem como buffer;
	 * recebe a imagem  do inimigo;
	 * */
	public Enemy(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
		enemyWalk = new BufferedImage[1];
		
		enemyWalk[0] = Jogo.spriteEnemy.getSprite(0, 0, 36, 36);
		
	}
	
	/* Renderiza graficamente a imagem do inimigo
	 * */
	public void render(Graphics g) {
		
		
		
		g.drawImage(enemyWalk[0], x, y, null);
		
		
		
		
	}
}