package entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Entity {

	protected static double x;
	protected static double y;
	protected int width;
	protected int height;
	
	private BufferedImage sprite;
	
	/* renderiza graficamente as imagens com entity entregando a localiza��o na tela
	 * */
	public Entity(int x, int y, int width, int height, BufferedImage sprite) {
		this.x = x;
		this.y = y;
		this.width= width;
		this.height = height;
		this.sprite = sprite;
	}
	
	public void setX(int newX) {
		this.x = newX;
	}
	public void setY(int newY) {
		this.y = newY;
	}
	
	public int getX() {
		return (int)this.x;
	}
	public int getY() {
		return (int)this.y;
	}
	public int getWidth() {
		return this.width;
	}
	public int getHeight() {
		return this.height;
	}
	public void update() {
		
	}
	
	/* renderiza graficamente as imagens com entity entregando a localiza��o na tela
	 * */
	public void render(Graphics g) {
		g.drawImage(sprite, this.getX(), this.getY(), null);
	}
}
