package entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import game_java.Jogo;

public class Player extends Entity {
	public boolean right, left, up, down;
	public int right_dir = 0, left_dir = 1, up_dir = 2,down_dir = 3;
	public int dir = right_dir;
	public double speed = 1.4;
	
	private int frames = 0, maxFrames = 6;
	private int index = 0, maxIndex = 7;
	
	private boolean moved = false;
	
	private BufferedImage[] rightPlayer;
	private BufferedImage[] leftPlayer;
	private BufferedImage[] upPlayer;
	private BufferedImage[] downPlayer;

	/* localiza as imagens com entity e inclui as anima��es em vetores de BufferedImage;
	 * */
	public Player(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
		rightPlayer = new BufferedImage[8];
		leftPlayer = new BufferedImage[8];
		upPlayer = new BufferedImage[8];
		downPlayer = new BufferedImage[8];
		
		for(int a = 0; a<8;a++) {
			leftPlayer[a] = Jogo.spriteSheet.getSprite(0 + (a*27), 0, 27, 36);
		}
		for(int b = 0; b<8;b++) {
			rightPlayer[b] = Jogo.spriteSheet.getSprite(216+(b*27), 0, 27, 36);
		}
		for(int c = 0; c<8;c++) {
			upPlayer[c] = Jogo.spriteSheet.getSprite(168+(c*21), 36, 21, 33);
		}
		for(int d = 0; d<8;d++) {
			downPlayer[d] = Jogo.spriteSheet.getSprite(0+(d*21), 36, 21, 33);
		}
	}
	
	/* atualiza os processo de acordo com a press�o dos bot�es chave e sua resposta em movimento;
	 * */
	public void update() {
		moved = false;
		if(right) {
			moved = true;
			dir = right_dir;
			x += speed;
		}else if(left) {
			moved = true;
			dir = left_dir;
			x -= speed;
		}
		
		if(up) {
			moved = true;
			dir = up_dir;
			y -= speed;
		}else if(down) {
			moved = true;
			dir = down_dir;
			y += speed;
		}
		if(moved) {
			frames++;
			if(frames == maxFrames) {
				frames = 0;
				index++;
				if(index > maxIndex) {
					index =0;
				}
			}
		}
		else {
			index =0;
		}
	}
	
	/* renderiza graficamente as anima��es do Player, indicando tamb�m  como o inimigo reage de acordo com
	 * sua localiza��o.
	 * imp�e os limites graficos de at� onde sua renderiza��o pode seguir na tela;
	 * */
	public void render(Graphics g) {
		
		if(dir == right_dir) {
			g.drawImage(rightPlayer[index],this.getX(),this.getY(), null);
		}else if(dir == left_dir) {
			g.drawImage(leftPlayer[index],this.getX(),this.getY(), null);
		}
		if(dir == up_dir) {
			g.drawImage(upPlayer[index],this.getX(),this.getY(), null);
		}
		if(dir == down_dir) {
			g.drawImage(downPlayer[index],this.getX(),this.getY(), null);
		}
		if(this.getX() > Enemy.x ) {
			Enemy.x +=speed;
		}
		else if(this.getX() < Enemy.x ) {
			Enemy.x -=speed;
		}
		else if(this.getY() < Enemy.y ) {
			Enemy.y -=speed;
		}
		else if(this.getY() > Enemy.y ) {
			Enemy.y +=speed;
		}
		
		if(this.getX() < 0) {
			this.setX(0);
		}
		else if(this.getX()>293) {
			this.setX(293);
		}
		
		if(this.getY() < 0) {
			this.setY(0);
			
		}
		else if(this.getY()>207) {
			
			this.setY(207);
			
		}
		//System.out.println(this.getX());
		//System.out.println(this.getY());

	}
}