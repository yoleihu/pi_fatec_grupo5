package game_java;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;

import banco.Banco;
import entities.Enemy;
import entities.Entity;
import entities.Player;
import graficos.Spritesheet;
import mapas.Outono;
import mapas.Verao;
import jframes.Ranking;
import jframes.Vitoria;
import mapas.Inverno;
import mapas.Primavera;

public class Jogo extends Canvas implements Runnable,KeyListener {

	private  boolean isRunning;
	private Thread thread;
	public static JFrame frame;
	private final int WIDTH = 320;
	private final int HEIGHT = 240;
	private final int SCALE = 3;
	
	private int time =0;
	
	private BufferedImage image;
	
	public static Spritesheet spriteSheet, spriteEnemy, spriteTileV, spriteTileO, spriteTileI, spriteTileP, spriteCristal;
	
	public List<Entity> entities;
	
	
	private Player player;
	private Enemy enemy;
	private Verao tileV;
	private Outono tileO;
	private Inverno tileI;
	private Primavera tileP;
	
	private String faseMap = "";
	public int numFase=1;
	
	private int codRank = 0;
	
	/* O construtor insere as imagens no construtor das fases, al�m de gerar um buffer para desenhar na tela;
	 * */
	public Jogo() {
		
		
		
		addKeyListener(this);
		setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
		initFrame();	
		//Inicializando os objetos
		
		image = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);
		entities = new ArrayList<Entity>();
		
		
		
		
		
		spriteTileV = new Spritesheet("/floorVerao2.png");
		tileV = new Verao(0, 0, 96, 32,spriteTileV.getSprite(0, 0, 96, 32));
		
		spriteTileO = new Spritesheet("/outonoFinal.png");
		tileO = new Outono(0, 0, 64, 32,spriteTileO.getSprite(0, 0, 64, 32));
		
		spriteTileI = new Spritesheet("/invernoFinal.png");
		tileI = new Inverno(0, 0, 128, 32,spriteTileI.getSprite(0, 0, 128, 32));
		
		spriteTileP = new Spritesheet("/primaveraFinal.png");
		tileP = new Primavera(0, 0, 64, 32,spriteTileP.getSprite(0, 0, 64, 32));
		
		
		spriteEnemy = new Spritesheet("/Morgana.png");
		enemy = new Enemy(0,0, 36, 36,spriteEnemy.getSprite(0, 0,36, 36));
		entities.add(enemy);

		
		spriteSheet = new Spritesheet("/all_walk_oficial.png");
		player = new Player(0, 0, 27, 36,spriteSheet.getSprite(0, 0, 27, 36));
		entities.add(player);
		
		spriteCristal = new Spritesheet("/cristal.png");
		
		
				
	}
	
	/* cria a tela
	 * */
	public void initFrame() {
		frame = new JFrame("Jogo PI");
		frame.add(this);// para ligar ao "setPreferredSize"
		frame.setResizable(false);// para n�o poderem modificar o tamanho
		frame.pack();
		frame.setLocationRelativeTo(null);// para deixar a janela ao meio da tela
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// op��o de sair
		frame.setVisible(true);
	}
	
	/* iniciar o jogo, com a Thread para ocorrer processos ao mesmo tempo;
	 * atualiza o banco quando iniciado;
	 * */
	public synchronized void start(int codRanking){
		thread = new Thread(this);
		isRunning = true;
		thread.start();
		this.codRank = codRanking;
		
	}
	
	/* para o jogo, suas threads e atualiza��es;
	 * */
	public synchronized void stop() {
		isRunning = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/* insere valores que ir�o correr a cada atualiza��o do jogo, ou seja, a cada "update"
	 * inserindo atualiza��o das entities e a valida��o de conclus�o ou derrota da fase;
	 * */
	public void update() {
		
		for(int i = 0; i < entities.size();i++) {
			Entity e = entities.get(i);
			e.update();	
		}
		
		if((player.getX() > 190 && player.getX()<220)&& (player.getY()> 70 && player.getY()<100)) {
			player.setX(0);
			enemy.x = 180;
			enemy.y = 100;
			this.setNumFase(this.getNumFase()+1);
			Banco banco = new Banco();
			banco.abreConexao();
			banco.trocaFase(codRank,this.getNumFase(),time);
			banco.fechaConexao();
		}
		if(enemy.x== player.getX() && enemy.y == player.getY()){
			System.out.println("peguei");
			
			enemy.x = 180;
			enemy.y = 100;
			Ranking rank = new Ranking("Ranking");
			rank.setVisible(true);
			rank.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
			frame.dispose();
			stop();
		}
	}
	
	public int getNumFase() {
		return numFase;
	}

	public void setNumFase(int numFase) {
		this.numFase = numFase;
	}
	public String getFaseMap() {
		return faseMap;
	}

	public void setFaseMap(String faseMap) {
		this.faseMap = faseMap;
	}
	
	/* renderiza graficamente as imagens de todo o jogo, desde seu background, at� o mapa, personagens e o tempo em cima;
	 * */
	public void render() {
		BufferStrategy bs = this.getBufferStrategy();// para pegar do Canvas
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = image.getGraphics();
		g.setColor(new Color(0,0,0));
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		
		
		//renderiza��o do jogo
		/*Graphics2D g2 = (Graphics2D) g; // Graphics2D faz com que a transforma��o gem�trica bidimensional seja poss�vel;
		g2.setColor(new Color(0,0,0,0)); // Aqui foi criado uma nova camada, onde foi poss�vel realizar um sistema de ilumina��o com a outra camada
		g2.fillRect(0,0,WIDTH, HEIGHT);*/
		// //
		
		
		switch(this.getNumFase()) {
		case 1:
			this.setFaseMap("verao");
			break;
			
		case 2:
			this.setFaseMap("outono");
			break;
			
		case 3:
			this.setFaseMap("inverno");
			break;
			
		case 4:
			this.setFaseMap("primavera");
			break;
			
		default:
			Vitoria vitoria = new Vitoria();
			vitoria.start();
			vitoria.frame.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
			frame.dispose();
			stop();
	}
		
		switch(this.getFaseMap()) {
			case "verao":
				tileV.render(g);
				break;
				
			case "outono":
				tileO.render(g);
				break;
				
			case "inverno":
				tileI.render(g);
				
				break;
				
			case "primavera":
				tileP.render(g);
				break;
		}
		
		g.setColor(Color.black);
		g.setFont(new Font("Arial", Font.BOLD, 11));
		g.drawString("time: " + String.valueOf(time),(WIDTH/2)-20, 10);
		
		//System.out.println(this.getFaseMap()+ " "+ this.getNumFase());
		
		
		for(int i = 0; i < entities.size();i++) {
				Entity e = entities.get(i); 
				e.render(g);
				
		}
		
		g.dispose();
		g = bs.getDrawGraphics();// peguei o gr�fico principal para 'desenhar' nele.
		
		g.drawImage(image,0,0,WIDTH*SCALE, HEIGHT*SCALE, null);
		bs.show();
	}

	
	/* ocorre o jogo, atualizando todos os processos por tempo e indicando a quantidade
	 * de frames por segundo (pode ser vista no console)
	 * */
	public void run() {
		long lastTime = System.nanoTime();
		double amountOfUpdates = 60.0;
		double ns = 1000000000/ amountOfUpdates;
		// pra explicar o ns, lembre que o computador conta em milisegundos 
		//portanto, se segundo � 1000 milisegundos, em nano, 1 segundo � 1000000000
		double delta = 0;
		int frames= 0;
		double timer = System.currentTimeMillis();
		
		
		while(isRunning) {
			long now = System.nanoTime();
			delta+= (now - lastTime)/ns;
			//quando der 1 no delta, ele fecha um update;
			lastTime = now;
			if(delta >= 1) {
				update();
				render();
				delta --;
				frames ++;
				
			}
			if( System.currentTimeMillis()- timer >=1000) {
				System.out.println("FPS: " + frames);
				frames=0;
				timer+=1000;
				time++;
			}
		}
		stop();
		
		
	}

	/* cria evento ligado ao Player dependente de qual bot�o do teclado � pressionado
	 * */
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_RIGHT ||
				e.getKeyCode() == KeyEvent.VK_D) {
			
			player.right = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_LEFT ||
				e.getKeyCode() == KeyEvent.VK_A) {
			player.left = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_UP ||
				e.getKeyCode() == KeyEvent.VK_W) {
			player.up = true;
		}
		else if(e.getKeyCode() == KeyEvent.VK_DOWN ||
				e.getKeyCode() == KeyEvent.VK_S) {
			player.down = true;
		}
	}

	/* finaliza o evento dependente de qual tecla havia sido pressionada e foi solta;
	 * */
	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_RIGHT ||
				e.getKeyCode() == KeyEvent.VK_D) {
			
			player.right = false;
		}
		else if(e.getKeyCode() == KeyEvent.VK_LEFT ||
				e.getKeyCode() == KeyEvent.VK_A) {
			player.left = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_UP ||
				e.getKeyCode() == KeyEvent.VK_W) {
			player.up = false;
		}
		else if(e.getKeyCode() == KeyEvent.VK_DOWN ||
				e.getKeyCode() == KeyEvent.VK_S) {
			player.down = false;
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}
