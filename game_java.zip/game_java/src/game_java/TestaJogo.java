package game_java;

import java.awt.Toolkit;

import jframes.TelaInicial;
import jframes.Vitoria;

public class TestaJogo {

	public static void main(String[] args) {
		TelaInicial telaInicial = new TelaInicial("Tela Inicial");
		telaInicial.setVisible(true);
		telaInicial.setIconImage(Toolkit.getDefaultToolkit().getImage("res\\mini_icon_luna.png"));
		
	}
	
	
}
